﻿using Entities.Models;
using System.Collections.Generic;

namespace Contracts
{
    public interface ICompanyRepository
    {
        void AnyMethodFromCompanyRepository();
        IEnumerable<Company> GetAllCompanies(bool trackChanges);
    }
}
